# Kritika Chugh <kchugh@syr.edu> SUID: 882046659
# Hemanta Kumar Pattnaik <hkpattna@syr.edu>
# For the grader: references for the code is mentioned in the paper.

import click
from PIL import Image
class Steganography(object):

    @staticmethod
    def __int_to_bin(rgb):

        r, g, b = rgb
        return ('{0:08b}'.format(r),
                '{0:08b}'.format(g),
                '{0:08b}'.format(b))

    @staticmethod
    def __bin_to_int(rgb):

        r, g, b = rgb
        return (int(r, 2),
                int(g, 2),
                int(b, 2))

    @staticmethod
    def __merge_rgb(rgb1, rgb2):

        r1, g1, b1 = rgb1
        r2, g2, b2 = rgb2
        rgb = (r1[:4] + r2[:4],
               g1[:4] + g2[:4],
               b1[:4] + b2[:4])
        return rgb

    @staticmethod
    def merge(coverImg, hiddenImg):

        if hiddenImg.size[0] > coverImg.size[0] or hiddenImg.size[1] > coverImg.size[1]:
            raise ValueError('Image 2 should not be larger than Image 1!')

        pixelMapForCoverImg = coverImg.load()
        pixelMapForHiddenImg = hiddenImg.load()

        new_image = Image.new(coverImg.mode, coverImg.size)
        pixels_new = new_image.load()

        for i in range(coverImg.size[0]):
            for j in range(coverImg.size[1]):
                rgb1 = Steganography.__int_to_bin(pixelMapForCoverImg[i, j])


                rgb2 = Steganography.__int_to_bin((0, 0, 0))

                if i < hiddenImg.size[0] and j < hiddenImg.size[1]:
                    rgb2 = Steganography.__int_to_bin(pixelMapForHiddenImg[i, j])


                rgb = Steganography.__merge_rgb(rgb1, rgb2)

                pixels_new[i, j] = Steganography.__bin_to_int(rgb)

        return new_image

    @staticmethod
    def unmerge(img):


        pixel_map = img.load()

        new_image = Image.new(img.mode, img.size)
        pixels_new = new_image.load()

        original_size = img.size

        for i in range(img.size[0]):
            for j in range(img.size[1]):

                r, g, b = Steganography.__int_to_bin(pixel_map[i, j])

                rgb = (r[4:] + '0000',
                       g[4:] + '0000',
                       b[4:] + '0000')


                pixels_new[i, j] = Steganography.__bin_to_int(rgb)

                if pixels_new[i, j] != (0, 0, 0):
                    original_size = (i + 1, j + 1)

        new_image = new_image.crop((0, 0, original_size[0], original_size[1]))

        return new_image


@click.group()
def cli():
    pass


@cli.command()
@click.option('--coverImg', required=True, type=str, help='Image that will hide another image')
@click.option('--hiddenImg', required=True, type=str, help='Image that will be hidden')
@click.option('--output', required=True, type=str, help='Output image')
def merge(coverImg, hiddenImg, output):
    merged_image = Steganography.merge(Image.open(coverImg), Image.open(hiddenImg))
    merged_image.save(output)


@cli.command()
@click.option('--img', required=True, type=str, help='Image that will be hidden')
@click.option('--output', required=True, type=str, help='Output image')
def unmerge(img, output):
    unmerged_image = Steganography.unmerge(Image.open(img))
    unmerged_image.save(output)


if __name__ == '__main__':
    cli()
